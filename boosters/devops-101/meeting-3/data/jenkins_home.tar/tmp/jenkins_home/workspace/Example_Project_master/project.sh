#!/bin/bash

# Display hostname of the current CI node
echo "Current CI hostname:"
hostname

# Display date and time on the current CI node
echo "Current date/time:"
date

exit 0
